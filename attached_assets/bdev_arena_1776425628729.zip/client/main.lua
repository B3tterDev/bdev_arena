ESX, NAS = nil, GetCurrentResourceName()
CreateThread(function()
    while not ESX do
        if Config.EventRoute['getSharedObject'] and type(Config.EventRoute['getSharedObject']) == "string" then
            TriggerEvent(Config.EventRoute['getSharedObject'], function(obj) ESX = obj end)
        end
        
        if Config.EventRoute['getSharedObject'] and type(Config.EventRoute['getSharedObject']) == "function" then
            ESX = Config.EventRoute['getSharedObject']()
        end
        Wait(100)
    end

    while not ESX.IsPlayerLoaded() do Wait(100) end
    while not ESX.GetPlayerData().job do
        Wait(100)
    end

    while not ESX.GetPlayerData().accounts do
        Wait(100)
    end

    while not ESX.GetPlayerData().inventory do
        Wait(100)
    end

    print('[^5'.. NAS .. '^0] Initializing data ..')
    while not NetworkIsPlayerActive(PlayerId()) do Wait(50) end
    print("[^2" .. NAS .. "^0] Verification successful, this resource is ^2READY ^0to use")
    Initial()
end)

function Initial()
    local Client = {}
    Client.dataJobs = {}
    Client.dataAccounts = {}
    Client.dataInventory = {}

    Client.dataTarget = {}
    Client.dataAction = {}
    
    RegisterNetEvent(Config.EventRoute['setJob'], function(job)
        Client.dataJobs = job
    end)

    RegisterNetEvent(Config.EventRoute['setAccountMoney'], function(account)
        Client.dataAccounts[account.name].count = account.money
    end)

    RegisterNetEvent(Config.EventRoute['addInventoryItem'], function(itemName, itemCount)
        if not Client.dataInventory[itemName] then return end
        Client.dataInventory[itemName].count = itemCount
    end)
    
    RegisterNetEvent(Config.EventRoute['removeInventoryItem'], function(itemName, itemCount)
        if not Client.dataInventory[itemName] then return end
        Client.dataInventory[itemName].count = itemCount
    end)

    Client.dataJobs = ESX.GetPlayerData().job
    for k, v in pairs(ESX.GetPlayerData().accounts) do
        Client.dataAccounts[v.name] = {
            label = v.label,
            count = v.money
        }
    end

    for k, v in ipairs(ESX.GetPlayerData().inventory) do
        Client.dataInventory[v.name] = {
            label = v.label,
            limit = v.limit,
            weight = v.weight or 0,
            count = v.count
        }
    end
    
    RegisterNetEvent(Config.EventRoute['onPlayerDeath'], function()
        isDead = true
    end)

    RegisterNetEvent(Config.EventRoute['onPlayerSpawn'], function()
        isDead = false
    end)
end