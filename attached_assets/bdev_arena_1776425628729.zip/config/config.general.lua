Config = Config or {}

Config.EventRoute = {
	['itemsImagePath'] = 'nui://nc_inventory/html/img/items',										-- ตำแหน่งของรูป Items | Default: 'nui://nc_inventory/html/img/items'
	['getSharedObject'] = function() return exports['es_extended']:getSharedObject() end,			-- Default: 'esx:getSharedObject'
	['onPlayerDeath'] = 'esx:onPlayerDeath',				-- Default: 'esx:onPlayerDeath'
	['onPlayerSpawn'] = 'playerSpawned',				-- Default: 'esx:onPlayerSpawn'
	['setJob'] = 'esx:setJob',								-- Default: 'esx:setJob'

	['setAccountMoney'] = 'esx:setAccountMoney',			-- Default: 'esx:setAccountMoney'
	['addInventoryItem'] = 'esx:addInventoryItem',			-- Default: 'esx:addInventoryItem'
	['removeInventoryItem'] = 'esx:removeInventoryItem',	-- Default: 'esx:removeInventoryItem'
}

Config.Arena = {
    MaxPlayers    = 5,          -- ผู้เล่นต่อทีม
    Rounds        = 3,          -- จำนวนรอบ
    MinBet        = 5000,       -- เดิมพันขั้นต่ำ
    MaxBet        = 5000000,    -- เดิมพันสูงสุด
    DefaultBet    = 50000,      -- เดิมพัน default
    RoundTimeSec  = 180,        -- เวลาต่อรอบ (วินาที)
    CountdownSec  = 10,         -- นับถอยหลังก่อนเริ่ม
    RoundEndSec   = 6,          -- หน่วงเวลาหลังจบรอบ
    GameEndSec    = 10,         -- หน่วงเวลาหลังจบเกม

    RedZone = {
        points = {
            vec3(194.0, -886.70001220703, 25.0),
            vec3(190.75, -885.5, 25.0),
            vec3(191.89999389648, -882.25, 25.0),
            vec3(195.19999694824, -883.45001220703, 25.0),
        },
        thickness = 5.5,
    },

    BlueZone = {
        points = {
            vec3(204.85000610352, -890.65002441406, 25.0),
            vec3(206.0, -887.40002441406, 25.0),
            vec3(209.30000305176, -888.59997558594, 25.0),
            vec3(208.10000610352, -891.84997558594, 25.0),
        },
        thickness = 5.5,
    },

    RedSpawn = {
        coords  = vec3(-1064.3, -258.0, 37.42),
        heading = 90.0,
    },
    BlueSpawn = {
        coords  = vec3(-1091.5, -240.0, 37.42),
        heading = 270.0,
    },

    -- ─── ออกจากสนาม ───
    ExitCoords  = vec3(-1077.69, -249.83, 37.42),
    ExitHeading = 0.0,
}