-- NC PROTECT+
shared_scripts { '@nc_PROTECT+/exports/protected.lua', '@nc_PROTECT+/exports/sh.lua' }

fx_version 'cerulean'
game 'gta5'
description 'B3tterDev Arena'
version '1.0.0'
use_fxv2_oal 'yes'
lua54 'yes'

shared_scripts {
	'@ox_lib/init.lua',
	'config/*.lua',
}

client_script {
	'client/main.lua'
}

server_script {
	'@mysql-async/lib/MySQL.lua',
	'server/main.lua',
}