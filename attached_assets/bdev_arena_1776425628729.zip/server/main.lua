local NAS = GetCurrentResourceName()
local Server = {}

if Config.EventRoute['getSharedObject'] and type(Config.EventRoute['getSharedObject']) == "string" then
    TriggerEvent(Config.EventRoute['getSharedObject'], function(obj) ESX = obj end)
end

if Config.EventRoute['getSharedObject'] and type(Config.EventRoute['getSharedObject']) == "function" then
    ESX = Config.EventRoute['getSharedObject']()
end