---@class UIClass
UIClass = {}
UIClass.__index = UIClass

function UIClass:New()
    local obj = setmetatable({}, UIClass)
    obj.hudVisible = false
    return obj
end

---@param msg   string
---@param ntype string  'success'|'error'|'warning'|'inform'
---@param title string|nil
function UIClass:Notify(msg, ntype, title)
    local typeMap = {
        success = 'success',
        error   = 'error',
        warning = 'warning',
        info    = 'inform',
        inform  = 'inform',
    }
    lib.notify({
        title       = title or 'Arena',
        description = msg,
        type        = typeMap[ntype] or 'inform',
        duration    = 5000,
    })
end

---@param round  number
---@param total  number
---@param scores table
function UIClass:ShowRoundInfo(round, total, scores)
    self.hudVisible = true
    SendNUIMessage({
        action = 'roundInfo',
        round  = round,
        total  = total,
        scores = scores,
    })
end

---@param seconds number
function UIClass:StartCountdown(seconds)
    SendNUIMessage({ action = 'countdown', seconds = seconds })
end

---@param streak number
function UIClass:UpdateStreak(streak)
    SendNUIMessage({ action = 'updateStreak', streak = streak })
end

function UIClass:HideHUD()
    self.hudVisible = false
    SendNUIMessage({ action = 'hideHUD' })
end

---@param data table
function UIClass:ShowResult(data)
    SendNUIMessage({ action = 'showResult', data = data })
end

function UIClass:HideResult()
    SendNUIMessage({ action = 'hideResult' })
end
