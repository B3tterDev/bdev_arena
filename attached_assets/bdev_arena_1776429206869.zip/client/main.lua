ESX, NAS = nil, GetCurrentResourceName()
local Arena, Player, UI

CreateThread(function()
    while not ESX do
        if Config.EventRoute['getSharedObject'] and type(Config.EventRoute['getSharedObject']) == "string" then
            TriggerEvent(Config.EventRoute['getSharedObject'], function(obj) ESX = obj end)
        end
        
        if Config.EventRoute['getSharedObject'] and type(Config.EventRoute['getSharedObject']) == "function" then
            ESX = Config.EventRoute['getSharedObject']()
        end
        Wait(100)
    end

    while not ESX.IsPlayerLoaded() do Wait(100) end
    while not ESX.GetPlayerData().job do
        Wait(100)
    end

    while not ESX.GetPlayerData().accounts do
        Wait(100)
    end

    while not ESX.GetPlayerData().inventory do
        Wait(100)
    end

    print('[^5'.. NAS .. '^0] Initializing data ..')
    while not NetworkIsPlayerActive(PlayerId()) do Wait(50) end
    print("[^2" .. NAS .. "^0] Verification successful, this resource is ^2READY ^0to use")
    Initial()
end)

function Initial()
    RegisterNetEvent(Config.EventRoute['onPlayerDeath'], function()
        isDead = true
    end)

    RegisterNetEvent(Config.EventRoute['onPlayerSpawn'], function()
        isDead = false
    end)

    Arena  = ArenaClass:New()
    Player = PlayerClass:New()
    UI     = UIClass:New()

    Arena:DrawBlips()
    TriggerServerEvent(NAS.. '.server.request.state')
    RegisterContextMenus()
    Arena:CreateZones(
        -- onEnterRed
        function() ShowLobbyMenu('red') end,
        -- onExitRed
        function() lib.hideContext() end,
        -- onEnterBlue
        function() ShowLobbyMenu('blue') end,
        -- onExitBlue
        function() lib.hideContext() end
    )
end

function RegisterContextMenus()
    lib.registerContext({
        id    = 'arena_red_lobby',
        title = '🔴 ทีมแดง — Arena Lobby',
        options = {
            {
                title       = '👑 สร้าง Lobby (Host)',
                description = 'ตั้งราคาเดิมพันและเปิด Lobby',
                icon        = 'crown',
                onSelect    = function() OpenCreateLobbyDialog('red') end,
            },
            {
                title       = '⚔️ เข้าร่วมทีมแดง',
                description = 'หักเงินเดิมพันทันที',
                icon        = 'right-to-bracket',
                onSelect    = function() TriggerServerEvent(NAS.. '.server.join.team', 'red') end,
            },
            {
                title       = '▶ Start Game',
                description = 'เฉพาะ Host (ผู้เล่นครบแล้ว)',
                icon        = 'play',
                onSelect    = function() TriggerServerEvent(NAS.. '.server.start.game') end,
            },
            {
                title       = '↩ ยกเลิก / Reset',
                description = 'เฉพาะ Host',
                icon        = 'rotate-left',
                onSelect    = function() ResetArenaConfirm() end,
            },
        },
    })

    lib.registerContext({
        id    = 'arena_blue_lobby',
        title = '🔵 ทีมน้ำเงิน — Arena Lobby',
        options = {
            {
                title       = '👑 สร้าง Lobby (Host)',
                description = 'ตั้งราคาเดิมพันและเปิด Lobby',
                icon        = 'crown',
                onSelect    = function() OpenCreateLobbyDialog('blue') end,
            },
            {
                title       = '⚔️ เข้าร่วมทีมน้ำเงิน',
                description = 'หักเงินเดิมพันทันที',
                icon        = 'right-to-bracket',
                onSelect    = function() TriggerServerEvent(NAS.. '.server.join.team', 'blue') end,
            },
            {
                title       = '▶ Start Game',
                description = 'เฉพาะ Host (ผู้เล่นครบแล้ว)',
                icon        = 'play',
                onSelect    = function() TriggerServerEvent(NAS.. '.server.start.game') end,
            },
            {
                title       = '↩ ยกเลิก / Reset',
                description = 'เฉพาะ Host',
                icon        = 'rotate-left',
                onSelect    = function() ResetArenaConfirm() end,
            },
        },
    })

    lib.registerContext({
        id    = 'arena_rejoin',
        title = '❌ คุณถูกกำจัด — Rejoin',
        options = {
            {
                title       = '🔴 Rejoin ทีมแดง',
                description = 'หักเงินเดิมพันอีกครั้ง | Streak รีเซ็ต',
                icon        = 'rotate-right',
                onSelect    = function() TriggerServerEvent(NAS.. '.server.rejoin.game', 'red') end,
            },
            {
                title       = '🔵 Rejoin ทีมน้ำเงิน',
                description = 'หักเงินเดิมพันอีกครั้ง | Streak รีเซ็ต',
                icon        = 'rotate-right',
                onSelect    = function() TriggerServerEvent(NAS.. '.server.rejoin.game', 'blue') end,
            },
        },
    })
end

---@param teamId string 'red'|'blue'
function ShowLobbyMenu(teamId)
    local s       = Arena.state
    local myId    = GetPlayerServerId(PlayerId())
    local isInTeam = Arena.myTeam ~= nil
    local isHost  = Arena.isHost
    local isReady = s == 'ready'

    local opts = {}

    if s == 'idle' then
        opts[#opts+1] = {
            title       = '👑 สร้าง Lobby (Host)',
            description = string.format('ตั้งราคาเดิมพัน — คุณจะเป็น %s',
                Utils.GetTeamLabel(teamId)),
            icon        = 'crown',
            onSelect    = function() OpenCreateLobbyDialog(teamId) end,
        }
    elseif s == 'lobby' or s == 'ready' then
        local redCount  = #Arena.teamRed
        local blueCount = #Arena.teamBlue

        if not isInTeam then
            local count = (teamId == 'red') and redCount or blueCount
            local full  = count >= Config.MaxPlayersPerTeam
            opts[#opts+1] = {
                title       = full
                    and string.format('❌ %s เต็มแล้ว (%d/5)', Utils.GetTeamLabel(teamId), count)
                    or  string.format('⚔️ เข้าร่วม%s (%d/5)', Utils.GetTeamLabel(teamId), count),
                description = not full
                    and string.format('เดิมพัน: %s | หักเงินทันที', Utils.FormatMoney(Arena.betAmount))
                    or  'ไม่สามารถเข้าร่วมได้',
                icon        = full and 'xmark' or 'right-to-bracket',
                disabled    = full,
                onSelect    = function()
                    if not full then TriggerServerEvent(NAS.. '.server.join.team', teamId) end
                end,
            }
        else
            opts[#opts+1] = {
                title       = string.format('✅ คุณอยู่%sแล้ว', Utils.GetTeamLabel(Arena.myTeam)),
                icon        = 'check',
                disabled    = true,
            }
        end

        opts[#opts+1] = {
            title       = string.format('🔴 ทีมแดง: %d/5   🔵 ทีมน้ำเงิน: %d/5', redCount, blueCount),
            icon        = 'users',
            disabled    = true,
        }

        if isHost then
            opts[#opts+1] = {
                title       = isReady and '▶ START GAME' or '⏳ รอผู้เล่นครบ...',
                description = not isReady
                    and string.format('ต้องการอีก %d คน',
                        (Config.MaxPlayersPerTeam - #Arena.teamRed) +
                        (Config.MaxPlayersPerTeam - #Arena.teamBlue))
                    or 'ผู้เล่นครบแล้ว! กด Start ได้เลย',
                icon        = 'play',
                disabled    = not isReady,
                onSelect    = function()
                    if isReady then TriggerServerEvent(NAS.. '.server.start.game') end
                end,
            }
            opts[#opts+1] = {
                title       = '↩ ยกเลิก / Reset',
                icon        = 'rotate-left',
                onSelect    = function() ResetArenaConfirm() end,
            }
        end
    elseif s == 'playing' then
        opts[#opts+1] = {
            title    = '⚔️ เกมกำลังดำเนินอยู่',
            description = string.format('Round %d/%d | 🔴 %d - %d 🔵',
                Arena.round, Config.TotalRounds,
                Arena.scores.red, Arena.scores.blue),
            icon     = 'swords',
            disabled = true,
        }
    end

    local menuId = 'arena_' .. teamId .. '_dynamic'
    lib.registerContext({
        id      = menuId,
        title   = (teamId == 'red') and '🔴 ทีมแดง — Arena Lobby'
                                     or '🔵 ทีมน้ำเงิน — Arena Lobby',
        options = opts,
    })
    lib.showContext(menuId)
end

---@param teamId string
function OpenCreateLobbyDialog(teamId)
    local betStr = table.concat((function()
        local t = {}
        for _, v in ipairs(Config.BetAmounts) do
            t[#t+1] = Utils.FormatMoney(v)
        end
        return t
    end)(), ' | ')

    local input = lib.inputDialog(
        string.format('สร้าง Lobby — %s', Utils.GetTeamLabel(teamId)),
        {
            {
                type        = 'number',
                label       = string.format('ราคาเดิมพัน (Min: %s | Max: %s)',
                    Utils.FormatMoney(Config.MinBet), Utils.FormatMoney(Config.MaxBet)),
                description = 'ตัวเลือกแนะนำ: ' .. betStr,
                default     = Config.DefaultBet,
                min         = Config.MinBet,
                max         = Config.MaxBet,
                required    = true,
            },
        }
    )

    if not input or not input[1] then return end

    local bet = math.floor(tonumber(input[1]) or Config.DefaultBet)
    TriggerServerEvent(NAS.. '.server.create.lobby', teamId, bet)
end

function ResetArenaConfirm()
    local confirmed = lib.alertDialog({
        header  = 'ยืนยันการ Reset',
        content = 'ยกเลิกเกมและคืนเงินให้ทุกคน?',
        cancel  = true,
    })
    if confirmed == 'confirm' then
        TriggerServerEvent(NAS.. '.server.reset')
    end
end

RegisterNetEvent(NAS.. 'client.state.update', function(data)
    Arena:ApplyState(data)
end)

RegisterNetEvent(NAS.. 'client.response', function(data)
    local ntype = data.success and 'success' or 'error'
    UI:Notify(data.message, ntype)
end)

RegisterNetEvent(NAS.. 'client.spawn.arena', function(teamId, round)
    Arena:SpawnToArena(teamId)
    UI:ShowRoundInfo(round, Config.TotalRounds, Arena.scores)

    Player:StartDeathDetection(function(killerId)
        TriggerServerEvent(NAS.. '.server.playerDied', killerId)
        Arena:EjectFromArena()
        UI:Notify('คุณถูกกำจัด! เดินกลับ Lobby เพื่อ Rejoin', 'error')
        lib.showContext('arena_rejoin')
    end)
end)

RegisterNetEvent(NAS.. 'client.eliminated', function(data)
    Arena:EjectFromArena()
    Player:StopDeathDetection()
    UI:Notify('คุณถูกกำจัด! เดินกลับ Lobby เพื่อ Rejoin', 'error')
    lib.showContext('arena_rejoin')
end)

RegisterNetEvent(NAS.. 'client.round.start', function(data)
    Arena.round  = data.round
    Arena.scores = data.scores
    lib.hideContext()
    UI:ShowRoundInfo(data.round, Config.TotalRounds, data.scores)
    UI:StartCountdown(data.duration)
    UI:Notify(string.format('Round %d/%d เริ่มแล้ว!', data.round, Config.TotalRounds), 'inform')
end)

RegisterNetEvent(NAS.. 'client.round.end', function(data)
    Arena.scores = data.scores
    local winLabel = data.winnerTeam and Utils.GetTeamLabel(data.winnerTeam) or 'เสมอ'
    UI:ShowRoundInfo(data.round, Config.TotalRounds, data.scores)
    UI:Notify(
        string.format('Round %d จบ — ผู้ชนะ: %s (🔴 %d - %d 🔵)',
            data.round, winLabel, data.scores.red, data.scores.blue),
        'inform'
    )
end)

RegisterNetEvent(NAS.. 'client.waiting', function(data)
    UI:Notify(
        string.format('Round %d — รอผู้เล่น Rejoin (เดินเข้า Lobby)', data.round),
        'warning'
    )
end)

RegisterNetEvent(NAS.. 'client.game.end', function(data)
    Player:StopDeathDetection()
    Arena:EjectFromArena()
    UI:HideHUD()
    UI:ShowResult(data)
    SetTimeout(8000, function()
        UI:HideResult()
    end)
end)

RegisterNetEvent(NAS.. 'client.streak.update', function(streak)
    Player:SetStreak(streak)
    UI:UpdateStreak(streak)
end)

RegisterNetEvent(NAS.. 'client.notify', function(msg, ntype)
    UI:Notify(msg, ntype)
end)
