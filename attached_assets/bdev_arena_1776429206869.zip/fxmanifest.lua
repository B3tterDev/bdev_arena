fx_version 'cerulean'
game 'gta5'
description 'B3tterDev Arena'
version '1.0.0'
use_fxv2_oal 'yes'
lua54 'yes'

dependencies {
    'ox_lib',
}

shared_scripts {
    '@ox_lib/init.lua',
    'shared/config.lua',
    'shared/utils.lua',
}

client_scripts {
    'client/arena_class.lua',
    'client/player_class.lua',
    'client/ui_class.lua',
    'client/main.lua',
}

server_scripts {
    'server/arena_manager.lua',
    'server/bank_class.lua',
    'server/main.lua',
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/css/style.css',
    'html/js/ui.js',
}
