NAS = GetCurrentResourceName()

-- Framework bridge
if Config.EventRoute['getSharedObject'] and type(Config.EventRoute['getSharedObject']) == "string" then
    TriggerEvent(Config.EventRoute['getSharedObject'], function(obj) ESX = obj end)
end

if Config.EventRoute['getSharedObject'] and type(Config.EventRoute['getSharedObject']) == "function" then
    ESX = Config.EventRoute['getSharedObject']()
end

local Arena = ArenaManager:New()

-- Host สร้าง Lobby
RegisterNetEvent(NAS.. '.server.create.lobby', function(teamId, betAmount)
    local src = source
    local ok, msg = Arena:CreateLobby(src, teamId, betAmount)
    TriggerClientEvent(NAS.. 'client.response', src, { success = ok, message = msg })
end)

-- ผู้เล่นเข้าร่วมทีม
RegisterNetEvent(NAS.. '.server.join.team', function(teamId)
    local src = source
    local ok, msg = Arena:JoinTeam(src, teamId)
    TriggerClientEvent(NAS.. 'client.response', src, { success = ok, message = msg })
end)

-- Host กด Start
RegisterNetEvent(NAS.. '.server.start.game', function()
    local src = source
    local ok, msg = Arena:StartGame(src)
    TriggerClientEvent(NAS.. 'client.response', src, { success = ok, message = msg })
end)

-- ผู้เล่นตาย (แจ้งจาก client)
RegisterNetEvent(NAS.. '.server.playerDied', function(killerId)
    local src = source
    Arena:OnPlayerDied(src, killerId)
end)

-- ผู้แพ้ Rejoin
RegisterNetEvent(NAS.. '.server.rejoin.game', function(teamId)
    local src = source
    local ok, msg = Arena:Rejoin(src, teamId)
    TriggerClientEvent(NAS.. 'client.response', src, { success = ok, message = msg })
end)

-- Host ยกเลิก / Reset
RegisterNetEvent(NAS.. '.server.reset', function()
    local src = source
    if Arena.host == src or IsPlayerAceAllowed(src, 'arena.admin') then
        Arena:Reset()
        TriggerClientEvent(NAS.. 'client.response', src, { success = true, message = 'Arena ถูก reset แล้ว' })
    else
        TriggerClientEvent(NAS.. 'client.response', src, { success = false, message = 'ไม่มีสิทธิ์ reset' })
    end
end)

-- ผู้เล่น Request สถานะปัจจุบัน
RegisterNetEvent(NAS.. '.server.request.state', function()
    local src = source
    TriggerClientEvent(NAS.. 'client.state.update', src, Arena:GetState())
end)

RegisterCommand('arenarest', function(source, args)
    if source == 0 or IsPlayerAceAllowed(tostring(source), 'arena.admin') then
        Arena:Reset()
        print('[ARENA] Admin reset by player ' .. tostring(source))
    end
end, false)

AddEventHandler('playerDropped', function(reason)
    local src = source
    local teamId = Arena:_GetTeamOf(src)
    if teamId then
        Arena:_RemoveFromTeam(src)
        Arena:_CheckRoundEnd()
        Arena:_BroadcastState()
        print(string.format('[ARENA] Player %d disconnected from team %s', src, teamId))
    end

    if Arena.host == src then
        print('[ARENA] Host disconnected — resetting arena')
        Arena:Reset()
    end
end)