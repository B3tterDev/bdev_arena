Config = {}

Config.EventRoute = {
	['getSharedObject'] = function() return exports['es_extended']:getSharedObject() end,			-- Default: 'esx:getSharedObject'
	['onPlayerDeath'] = 'esx:onPlayerDeath',				-- Default: 'esx:onPlayerDeath'
	['onPlayerSpawn'] = 'playerSpawned',				-- Default: 'esx:onPlayerSpawn'
}

Config.MaxPlayersPerTeam = 5
Config.TotalRounds       = 3
Config.RoundDuration     = 300          -- วินาที/Round (5 นาที)
Config.BetAmounts        = { 10000, 25000, 50000, 100000, 250000 }
Config.DefaultBet        = 50000
Config.MinBet            = 5000
Config.MaxBet            = 1000000

Config.Teams = {
    red  = { id = 'red',  label = 'ทีมแดง', color = '#e74c3c', oxColor = 'red'  },
    blue = { id = 'blue', label = 'ทีมน้ำเงิน', color = '#2980b9', oxColor = 'blue' },
}

Config.ArenaCenter = vector3(-414.0, -2057.0, 13.0)
Config.ArenaRadius  = 30.0

Config.SpawnPoints = {
    red  = vector4(-420.0, -2057.0, 13.0, 90.0),
    blue = vector4(-408.0, -2057.0, 13.0, 270.0),
}

Config.RedLobby = {
    points = {
        vec3(194.0,           -886.70001220703, 25.0),
        vec3(190.75,          -885.5,           25.0),
        vec3(191.89999389648, -882.25,           25.0),
        vec3(195.19999694824, -883.45001220703, 25.0),
    },
    thickness = 5.5,
}

Config.BlueLobby = {
    points = {
        vec3(204.85000610352, -890.65002441406, 25.0),
        vec3(206.0,           -887.40002441406, 25.0),
        vec3(209.30000305176, -888.59997558594, 25.0),
        vec3(208.10000610352, -891.84997558594, 25.0),
    },
    thickness = 5.5,
}

Config.EjectPoint = vector3(200.0, -887.0, 25.0)